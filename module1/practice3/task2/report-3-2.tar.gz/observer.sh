#!/bin/bash
CONFIG_FILE="observer.conf"

LOG_FILE="observer.log"
 if [[ ! -f "$CONFIG_FILE" ]]; then
   echo "Файл конфигурации $CONFIG_FILE не найден!" >&2
   exit 1
 fi
while read -r SCRIPT_PATH; do
   if [[ -z "$SCRIPT_PATH" ]]; then
    continue
   fi
   if ! pgrep -f "$SCRIPT_PATH" > /dev/null; then
   nohup "$SCRIPT_PATH" > /dev/null 2>&1 &
    echo "$(date '+%Y-%m-%d %H:%M:%S') Скрипт $SCRIPT_PATH перезапущен" >> "$LOG_FILE"
    fi
done < "$CONFIG_FILE"
