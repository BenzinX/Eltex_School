#include <string.h>
#include <math.h>
#include <stdio.h>

double calculate(double a, double b) {
    if (b == 0) {
        fprintf(stderr, "Ошибка: деление на ноль!\n");
        return NAN;
    }
    return a / b;
}

void get_info(char* name, char* description) {
    strcpy(name, "div");
    strcpy(description, "деление");
}
