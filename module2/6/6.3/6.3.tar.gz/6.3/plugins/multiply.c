#include <string.h>

double calculate(double a, double b) {
    return a * b;
}

void get_info(char* name, char* description) {
    strcpy(name, "mul");
    strcpy(description, "умножение");
}
