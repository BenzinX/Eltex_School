#include <string.h>
#include <math.h>

double calculate(double a, double b) {
    return pow(a, b);
}

void get_info(char* name, char* description) {
    strcpy(name, "pow");
    strcpy(description, "возведение в степень");
}
