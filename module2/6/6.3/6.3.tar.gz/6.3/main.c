#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <dlfcn.h>
#include <dirent.h>
#include <sys/stat.h>

// Структура команды
typedef struct {
    char name[16];
    char description[64];
    double (*func)(double, double);
    void* library; // Дескриптор библиотеки
} Command;

// Прототипы функций
void show_help(Command* commands, int count);
void clear_input_buffer();
int load_plugins(Command** commands, int* count);

// Освобождение памяти и библиотек
void free_commands(Command* commands, int count) {
    for (int i = 0; i < count; i++) {
        dlclose(commands[i].library);
    }
    free(commands);
}

int main() {
    setlocale(LC_ALL, "ru_RU.UTF-8");

    Command* commands = NULL;
    int command_count = 0;

    // Загрузка плагинов
    if (!load_plugins(&commands, &command_count)) {
        printf("Ошибка загрузки плагинов.\n");
        return 1;
    }

    if (command_count == 0) {
        printf("Не найдено ни одной команды.\n");
        free_commands(commands, command_count);
        return 1;
    }

    show_help(commands, command_count);

    char input[32];
    double a, b;

    while (1) {
        printf("> ");
        if (scanf("%s", input) != 1) {
            clear_input_buffer();
            continue;
        }

        if (strcmp(input, "exit") == 0) break;
        if (strcmp(input, "help") == 0) {
            show_help(commands, command_count);
            continue;
        }

        // Поиск команды
        int found = 0;
        for (int i = 0; i < command_count; i++) {
            if (strcmp(input, commands[i].name) == 0) {
                found = 1;
                printf("Введите a и b: ");
                if (scanf("%lf %lf", &a, &b) == 2) {
                    double res = commands[i].func(a, b);
                    printf("Результат = %lf\n", res);
                } else {
                    clear_input_buffer();
                    printf("Введите два числа!\n");
                }
                break;
            }
        }

        if (!found) {
            printf("Неизвестная команда. Введите 'help'.\n");
            clear_input_buffer();
        }
    }

    free_commands(commands, command_count);
    return 0;
}

// Загрузка плагинов из папки plugins
int load_plugins(Command** commands, int* count) {
    DIR* dir;
    struct dirent* entry;
    char path[] = "plugins";
    *commands = NULL;
    *count = 0;

    // Создание папки plugins, если не существует
    mkdir(path, 0755);

    dir = opendir(path);
    if (!dir) {
        return 0;
    }

    // Подсчет .so файлов
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG && strstr(entry->d_name, ".so") != NULL) {
            (*count)++;
        }
    }
    closedir(dir);

    if (*count == 0) return 1;

    // Выделение памяти под команды
    *commands = (Command*)calloc(*count, sizeof(Command));
    if (!*commands) return 0;

    // Загрузка библиотек
    dir = opendir(path);
    int index = 0;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG && strstr(entry->d_name, ".so") != NULL) {
            char dll_path[256];
            snprintf(dll_path, sizeof(dll_path), "%s/%s", path, entry->d_name);
            void* lib = dlopen(dll_path, RTLD_LAZY);
            if (lib) {
                // Получение функции calculate
                double (*calculate)(double, double) = dlsym(lib, "calculate");
                // Получение функции get_info
                void (*get_info)(char*, char*) = dlsym(lib, "get_info");
                if (calculate && get_info) {
                    get_info((*commands)[index].name, (*commands)[index].description);
                    (*commands)[index].func = calculate;
                    (*commands)[index].library = lib;
                    index++;
                } else {
                    dlclose(lib);
                }
            }
        }
    }
    closedir(dir);

    *count = index; // Обновляем количество успешно загруженных команд
    return 1;
}

// Вывод списка команд
void show_help(Command* commands, int count) {
    printf("Доступные команды:\n");
    for (int i = 0; i < count; i++) {
        printf("%d. %s - %s\n", i + 1, commands[i].name, commands[i].description);
    }
    printf("\n   help - показать справку\n");
    printf("   exit - выход\n");
}

void clear_input_buffer() {
    while (getchar() != '\n');
}
