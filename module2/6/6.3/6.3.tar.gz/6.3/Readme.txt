Создайте папку для сборки и выполните сборку:

mkdir build
cd build
cmake ..
cmake --build .

Запуск

После сборки запустите программу из папки build:

./calculator
